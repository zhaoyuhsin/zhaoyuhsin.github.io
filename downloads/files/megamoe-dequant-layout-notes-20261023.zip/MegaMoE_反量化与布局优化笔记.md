# MegaMoE中数据排布与依赖的优化

融合算子的优化过程中，注意两件事：**下一步按什么顺序读数据；下一步到底在等什么。** 前者决定布局，后者决定调度。

本文以950DT、小M的A8W4后端为例，代码参照本地原Wave恢复版 `fd7e20e`。历史实验分开标注，不把不同分支的收益拼成一个版本。

阅读顺序：**任务怎么切 → 缓冲放哪里 → 谁搬、谁算、谁等 → 为什么改布局和依赖。** 配图均为逻辑示意，不表示实测耗时；内存容量和地址另有明确标注。

## 一、反量化&矩阵乘过程

### 1. 计算任务tile级划分

如下图所示，整体计算任务进行tile级切分，调度的M-block上限为256、物理tile_N为256。**尾块或小专家的有效M不一定为256**，本文固定用有效M128，命中 `MakeA8W4KPlan(m <= 128)`。

![整体矩阵与N256、K512分块示意，保留原图](image.png)

以有效行数M=128、输出N=256为例：

```text
       A：激活FP8               B：权重FP4              C：累加FP32
       128 × 7168       ×       7168 × 256       =       128 × 256
        token × K                 K × N                    M × N
```

A是token特征，B是权重。权重在GM中经常用 `W[N,K]` 的物理视图保存，但不因此变成数学上的A。
这里的“小M”不等于每卡BS很小：EP8、384专家、topk6、均衡路由时，每卡BS1024恰好对应每专家128个token。


### 2. 每个tile的B矩阵权重搬运

先看完整GMM1权重：K7168×N6144。**N6144包含24个N256任务，下面只选其中一个讲解。** 图中固定横轴N、纵轴K，灰色部分是其他任务，不是空白内存。

![完整K7168和N6144的权重任务图，突出单个N256任务中的P0至P27](./megamoe-layout-figures/11-full-weight-task-map-v2.png)

选中任务按K512推进，共14个窗口；每个窗口再分两个N128半块。因此有28个P，按P0、P1、P2、P3……供数。每个P为N128×K512，packed FP4为32KiB，展开FP8后为64KiB。这不是把整个权重提前展开成FP8。
![L1及L0A、L0B、L0C内存分区](megamoe-layout-figures/01-l1-l0-layout.png)

现在倒推为什么这样设计。当前窗口为A128×512、B512×256、C128×256：

1. **“双buffer，所以每槽32KiB”在本实现里是对的。** L0A、L0B各64KiB，当前各分两槽，得到每槽32KiB。FP8的A128×256、B256×128恰好各占一槽。因此A沿K切两份，B沿K和N各切两份，共四份。双槽是本版的流水选择，不是硬件规定只能这样分。
2. **K512是L1供数窗口，K256是L0计算分段。** 这不是把K分给多个核、最后归约的split-K。它只是同一个tile内部沿K推进，部分和始终由同一AIC在L0C累加。

> Q1：为什么不直接tile_N=128、K窗口=256？K512为什么能摊薄边界？

这是合法的另一种设计，不是不能做。当前选择主要换取两种复用：

- **保留N256：同一份A服务两个N128。** 若拆成两个独立N128任务，又没有跨任务A驻留，则两项都要装载同一批A；对应的L1→L0A装载量会从一次变两次，GM→L1的请求量也可能增加。但HBM流量未必翻倍，还取决于L2和驻留策略。GMM1的N256还对应gate128＋up128的配对输出，改N也要一起改消费者。
- **L1按K512供数：不改变L0的K256计算。** 完整K7168若按K256供数，要推进28个窗口；K512只需14个。每窗的寻址、提交、完成通知与槽位管理有一部分固定成本；搬更大一批，可以减少这些边界的次数，而不是减少权重总字节数或MMAD工作量。

```text
                              L1供数K256         L1供数K512（当前）
完整K7168的窗口数                   28                  14
N256每窗的N128反量化调用数           2                   2
整个任务的反量化调用数               56                  28
L0按K256、N128计算的调用数           56                  56
有效A/B总字节数、数学工作量          相同                相同
```

代价是每次交接的数据更多，首块可能更晚就绪，占用容量也更大。因此不是“N和K越大越好”：当前N256/K512是在A复用、缓冲容量、启动延迟和并行任务数之间的选择，不能据此断言所有shape最优。

> Q2：为什么SF槽是16KiB，覆盖N256×K2048，相当于八个权重小块？是否因为小搬运打不满带宽？

前半句正确，但要补上**每K32一个E8M0 scale，仅1B，不是FP32**。一个P的SF是 `128×(512/32)×1B=2KiB`；四个K512窗口、每窗两个N128，共八个P，SF合计16KiB。

```text
同一 SB 槽：N256 × K2048 的 scale，16KiB
                         N[0,128)     N[128,256) → N
K[0,512)                   P0 SF         P1 SF
K[512,1024)                P2 SF         P3 SF
K[1024,1536)               P4 SF         P5 SF
K[1536,2048)               P6 SF         P7 SF
    ↓ K                 每格2KiB，八格共用一批SF搬运
```

代码依据是 `l1ScaleTileK = L1_TILE_K × L1_SCALE_FACTOR_K = 256 × 8 = 2048`。这里用的是**模板基准K256**，不是运行时小M的K512，不能误算成512×8。SF有自己跨四个窗口的生命周期，最后一次MTE1读取完成后才归还槽位。

较大SF窗口可以摊薄提交与同步，重排后也便于连续读取；但“此前已经MTE2队列bound、带宽打不满”还只是机制假设，不能仅凭2KiB很小就下结论。16KiB是这份缓冲规划的选择，不是SF硬件格式强制的容量。

| 粒度 | 为什么这样选 |
|---|---|
| 有效M128 | 本例的token行数，也满足小M路径容量条件；调度M-block上限仍可为256 |
| 任务N256 | 一次覆盖两个N128半块，允许同一份L0A激活被两半权重复用 |
| L1的K512 | A槽64KiB刚好容纳128×512个FP8；较长K窗口可摊薄供数边界 |
| 权重N128×K512 | 展开后64KiB，恰好一个L1B槽；N256×K512是128KiB，不能塞进一个槽 |
| L0的K256、N128 | 各32KiB操作数槽可装A的128×256和B的256×128，并保留双缓冲 |
| K32分组 | 对应这里的FP8 C0/MX scale组织粒度；不是一次完整计算任务 |

特别区分“32×128小块”和DMA：一个P包含16个 **K32×N128** 分组，每组packed FP4为2KiB、FP8为4KiB。
它是NZ组织单元，**不表示当前每次DMA只搬4KiB**。预排后的GM→UB可连续读取整个32KiB；UB→L1则从交错槽中按256B片段收集64KiB。


### 3. 矩阵乘过程

![一个K512窗口的激活、权重分块及四次MMAD的槽号](megamoe-layout-figures/02-four-mmad-steps.png)

先假设各游标从0开始。AIV0准备P0、P1，分别写入L1B0、B1；下一个K512窗口使用B2、B3，再按credit轮转，不能覆盖尚未释放的槽。

```text
                     B，当前K512×N256
                       N左128       N右128
                     ┌───────────┬───────────┐
A，当前M128×K512     │ B00       │ B01       │ K[0,256)
┌─────────┬─────────┐│ 来自L1B0  │ 来自L1B1  │
│ A0      │ A1      │├───────────┼───────────┤
│128×256  │128×256  ││ B10       │ B11       │ K[256,512)
└─────────┴─────────┘│ 来自L1B0  │ 来自L1B1  │
                     └───────────┴───────────┘

① A0×B00 ──► C左       ② A0×B01 ──► C右
③ A1×B10 ──► C左累加   ④ A1×B11 ──► C右累加
```

| 顺序 | L1→L0A | L1→L0B | 计算与输出位置 |
|---:|---|---|---|
|①|A的K[0,256)→A槽0|L1B0的前半K→B槽0|128×256乘256×128，累加C左|
|②|不重搬，复用A槽0|L1B1的前半K→B槽1|同一A乘N右半，累加C右|
|③|A的K[256,512)→A槽1|L1B0的后半K→B槽0|继续累加C左|
|④|不重搬，复用A槽1|L1B1的后半K→B槽1|继续累加C右|

四次是分块MMAD调用，**不是四块互不重叠的输出，也不是四条底层指令**。输出只有左右两个半块；后两次沿K累加到原位置。完整K有14个窗口，共28次权重展开、56次此粒度计算。部分和一直留在L0C，完整K结束才FIX输出；代码还允许左半最后一次计算后先提交其FIX，与右半收尾重叠。

配合靠的是完成事件，不靠两个角色“跑得差不多快”：

```text
AIV0：等B槽EMPTY → UB→L1 → MTE3发布FULL
                                  │
AIC ：                       MTE1等FULL → L1→L0B → 发布EMPTY

AIC内部：MTE1_M保证装载先于MMAD；M_MTE1保证MMAD读完才覆盖L0槽。
GMM1输出：真正FIX完成 → AIV1消费 → 最后读取完成后归还输出槽credit。
```

本版L1B的FULL为4～7、EMPTY为8～11；不是全卡屏障。B槽在最后一次L1→L0读取完成后即可复用，无需等整个GMM结束。



SF是Scale Factor。这里每K32一份 **E8M0，1字节**，不是FP32。权重SF槽一次覆盖K2048、N256，因此 `2048/32×256×1B=16KiB`，可以服务四个K512窗口。A-scale物理槽也按最大容量预留16KiB，本例M128的有效数据为8KiB。

### 4. AIV0做什么，scale在哪里生效（这里顺便讲解一下aiv0反量化的过程）

```text
GM：packed FP4
       │ MTE2，读取32KiB
       ▼
AIV0输入UB ── Vector解包/位变换 ──► AIV0输出UB：FP8 64KiB
                                           │ MTE3
                                           ▼
                                      L1B：64KiB
                                           │ MTE1，带MX scale装载
                                           ▼
                                         L0B
```

这段Vector代码主要是格式展开，不是把所有scale逐元素乘进权重：FP4解码值 `q4` 被编码成FP8值 `q4/64`，块scale仍独立供给Cube，FIX输出时补乘64。比如 `q4=6、S_B=2`，L1中FP8值为0.09375；结合块scale及最终×64，仍对应真实权重12。

一个K32×N128分组包含4096个FP8元素。当前预排NZ路径每轮处理 **8行N×32个K＝256个权重**：读取128B packed FP4，展开并位转换，写出256B FP8。一个子区域沿N处理16轮；一个P沿K有16个子区域，因此共 `16×16＝256轮`。

![P0到K32子区域再到256元素Vector轮次的逐层展开](megamoe-layout-figures/08-p0-vector-breakdown.png)

对应 `RegComputeNz` 的循环就是：

```cpp
for (loopKIdx = 0; loopKIdx < 16; ++loopKIdx)  // P内16个K32
    for (panelIdx = 0; panelIdx < 1; ++panelIdx) // 本次P只有一个N128
        for (vectorIdx = 0; vectorIdx < 16; ++vectorIdx) {
            // 同一K32内依次处理N[0,8)、[8,16)……[120,128)
            LoadAlign(...);                    // 128B packed → 256个lane
            ShiftLeft(...); ShiftRight(...); And(...);
            StoreAlign(...);                   // 写256B FP8，槽内物理步长512B
        }
```

这是循环结构示意，不是可编译代码。**256轮不等于256个cycle，也不是调用256次VF**；一次 `RegComputeNz` 执行内部全部循环，每轮还包含多条向量指令。GM→UB仍可一次连续读入整个P的32KiB，不是每处理一个K32就重新发起一次GM DMA。

AIV0使用三份32KiB输入UB、两份64KiB输出UB，两套槽位独立轮转：输入在Vector最后读取后归还，输出等MTE3最后读取后归还。UB分区、padding及交错双槽的bank分析另见[UB bank冲突笔记](MegaMoE_UB_bank冲突笔记.md)，不在本文展开。

### 5. FIX完成通知与AIV1的CV槽：两个容易混淆的点

“完成协议”回答**什么时候可以读、什么时候可以覆盖**；“原地压缩”回答**激活量化后更小的数据放在哪里**。两者配合，但不是同一个优化。

![两credit完成协议及AIV1 CV槽原地压缩](megamoe-layout-figures/07-credit-and-cv.png)

- **FULL不是“任务提交了”。** GMM1的gate/up真正FIX写完，FIX流水才发FULL；AIV1的Vector等FULL后才能读。AIC的Scalar可以继续提交独立任务，不需要每个tile都自己排空FIX。
- **EMPTY是覆盖许可，不是数据清零。** AIV1完成激活、量化和写出后，MTE3队列归还EMPTY；AIC再次使用同一输出槽前必须取得它。两个槽可容纳两份在途输出，第三份要等第一份归还，不能无限提前。
- **原地压缩：64KiB BF16输入变成16KiB FP8结果。** 每次处理32行，读16KiB BF16，生成4KiB FP8，写入该槽已消费的前缀；不会覆盖后面未读的行。四次做完，再按一个128行stage提交数据与scale写出。数据可用二维DMA写往GM，不等于GM目标也是连续16KiB。
- **槽仍然占64KiB。** 512B MX scale另存scratch；压缩只是复用已读空间，不是把物理槽缩小，更不是允许FIX提前覆盖。
- **融合VF融合的是执行结构，保留原舍入规则。** 此处依次保留SwiGLU→BF16 RN、最大指数MX scale、乘scale后的BF16舍入、FP8 RN；不是为了少几条指令偷偷改成另一套量化算法。

补充版本边界：**统一任务流实验版（small-linear）**让GMM1、GMM2共用递增sequence与两份FULL/EMPTY credit，AIV1按同一任务流处理完成通知。GMM1完成后消费CV数据；GMM2完成后发布Combine贡献，**GMM2结果仍写GM，不占CV数据槽**。这样可避免在AIC的每段GMM2结束处反复Scalar排空。

本文基准已经恢复原Wave，入口调用 `ProcessGmmWaves` / `ProcessAiv1PriorityStages`，**不调用small-linear任务流**。它保留GMM1的CV消费，但不能把“GMM1/GMM2共用sequence”误认为原Wave也已启用。


## 二、两类有效优化

### 第一类：按消费者的访问顺序组织数据

沿数据流逐层反推，而不是要求所有层使用同一种布局：

```text
GM权重       →       输入UB       →       输出UB        →      L1/L0
MTE2想连续读        Vector想连续展开      V写/MTE3读少争用       Cube按分形消费

GM的最优格式 ≠ UB的最优格式；层间转换有时值得保留。
```

#### 1. GM中权重scale的排布优化：权重SF改为pair-major

先把消费者的范围对齐：**AIV0一次处理N128×K512的权重P；AIC侧一次准备N256×K2048的权重scale，覆盖P0～P7**。二者不必采用同一个批次大小。

下图前后都用**横轴N、纵轴K**。格子表示同一批逻辑数据，边上的箭头表示物理存放顺序；最下方另画一维GM地址条，避免把坐标方向和内存顺序混淆。

![同一P0到P7范围对应的SF，以及N-major与pair-major前后连续性](megamoe-layout-figures/10-sf-p0-p7-layout.png)

记 `S(n,q)` 是输出通道n、第q个K64的scale pair，两个字节分别覆盖相邻两个K32。忽略专家维：

```text
旧 GM：[N][K/64][2]                 同一个 N 的全部 K scale 连续
新 GM：[N/256][K/64][N内256][2]     同一个 q 的 N256 scale 连续
```

以完整K7168的首个K2048窗口为例：旧布局固定一个N，沿K存完全部scale，占224B，本次只取前64B，共256段；新布局固定一个q，沿N存完256个pair，占512B，q0～q31连起来正好16KiB。最后一个K窗口只有1024时，实际权重scale为8KiB，物理槽仍预留16KiB。



#### 2. GM中权重本体的排布优化：FP4本体按K512/N128窗口预排

原路径已是packed NZ，不是每次现场做ND→NZ。问题是目标窗口在整矩阵NZ条带中不连续。
沿用前面的P编号：`T0左…T15左`是P0内的16个N128×K32子区域，`T0右…T15右`属于P1。每个T为packed 2KiB，同一ID始终代表同一批权重。

同样固定**横轴N、纵轴K**：优化前在一个K32内沿N存放，再换下一个K32；优化后先把一个N128面板的16个K32子区域放完，即整个P0，再放P1。

![P0在全局NZ中分散成16段，以及预排后整个P0连续32KiB](megamoe-layout-figures/09-fp4-p-window-layout.png)

旧GM按完整N排每个K32条带：取P0时，要从16条条带各取2KiB。新GM把P0的16段放到一起，再放P1，当前P的32KiB可连续读入。旧路径可使用带stride的DMA，**16个源片段不等于16次DMA API调用**。

新物理顺序是 `[N256块][K512窗口][N128半区][K32][N128][16B packed]`。搬入UB后，每个P仍然执行上一节的256轮转换；重排改善取数组织，不减少权重元素数或反量化轮数。

目标是让Prologue连续取得当前要展开的权重，不是提前转成FP8。要同时修改权重准备、GM寻址和局部遍历；旧prepared缓存不能混用。离线预排在kernel计时外，若每次调用都重排，还需另算总成本。

#### 对应收益：只看各自父版，不能相加

测量为完整通信kernel Duration、timer-off、EP8、均衡路由、无共享专家，BS为每卡值。每项相对各自父版本比较，不是同一基线上的可累加收益。

| 改动 | BS512减少 | BS1024减少 |
|---|---:|---:|
|权重SF按N256块内pair-major重排|24.33μs / 3.12%|27.44μs / 2.48%|
|按完整专家M选择SF缓存：单M块不填L2、多M块保留复用|21.87μs / 2.90%|0.95μs / 0.09%，收益很弱|
|FP4权重按K512/N128消费窗口预排|3.84μs / 0.52%|4.14μs / 0.39%|

FP4预排的这组测量来自采用DeepSeek量化/舍入规则的实验路径，不能直接算作当前保留原数学规则路径的独立收益；相关优化迁回原数学规则后，组合性能另行重测。

### 第二类：画DAG，去掉不必要的等待

**激活A依赖Dispatch完成，静态权重scale不依赖它。** 因此先提交权重scale搬运，再等待激活ready，用原本的等待窗口覆盖独立工作。

![GMM1依赖DAG与B-scale前移前后的同轴流水](megamoe-layout-figures/06-dag-and-prefetch.png)

| 优化 | BS512减少 | BS1024减少 |
|---|---:|---:|
|CATLASS后端：权重scale搬运移到等待输入之前|4.87μs / 0.66%|8.03μs / 0.75%|

条件同上，相对该项父版本。**只前移独立工作，不删真实依赖：** SF槽先拿到EMPTY，A及A-scale仍等ready，MTE1消费前仍等搬运完成。

## 三、总结

### 1. 从消费者反推布局，但不要只做局部贪心

可以沿整个链路追问：

```text
GMM1 FIX输出 → SwiGLU读gate/up → MX量化写激活与SF → GMM2读取
    写得顺？       配对方便？          写得顺？            读得顺？
```

以SwiGLU为消费者，一个合理方向是按通道块配对gate/up：

```text
整分支分离：[G0 G1 G2 …][U0 U1 U2 …]
分块配对  ：[G0 U0][G1 U1][G2 U2] …    每个G/U块含128列
```

这样同一批行的gate/up更容易一起就绪、就近消费。当前paired GMM1/CV已经使用这种思路：物理N256是gate128＋up128，SwiGLU输出128列；不能把已有配对再当一次新收益。

继续优化应同时看三件事：FIX能否高效写、Vector是否连续读、量化后的数据和SF是否适合GMM2。尤其SF可以与激活本体采用不同布局。
不能直接断言逐元素 `g0,u0,g1,u1…` 最优，也不能为了GMM2连续读，把SwiGLU写端变成更贵的散写。目标是整条关键路径最短，不是每个模块单独最快。

### 2. GMM1的任务顺序，要服务于GMM2的就绪条件

普通GMM2的一个输出tile需要同一批行的完整中间维度I，而不只是某一片通道：

```mermaid
flowchart LR
    G0["GMM1：M0，gate/up块0"] --> Q0["SwiGLU/MX：H0完成"]
    G1["GMM1：M0，gate/up块1"] --> Q1["SwiGLU/MX：H1完成"]
    GN["GMM1：M0，其余通道块"] --> QN["其余H完成"]
    Q0 --> R["M0的完整I与SF就绪"]
    Q1 --> R
    QN --> R
    R --> M2["GMM2：M0，各输出N块"]
```

因此，想更早启动GMM2，可以优先把**一个M-block的全部N-block做完**。这里“优先M-block完成”明确指固定M、遍历N，避免和“M索引变化最快”混淆。

原Wave的通用调度器是 `GemmIdentityBlockSwizzle<3,0>`：在最多3个M-block组成的条带内，先沿M再沿N推进。用3个M、4个N的任务编号示意：

```text
swizzle：相同N轮过三个M          固定M，把全部N先做完
         N0 N1 N2 N3                    N0 N1 N2 N3
    M0 [ 1  4  7 10]               M0 [ 1  2  3  4]
    M1 [ 2  5  8 11]               M1 [ 5  6  7  8]
    M2 [ 3  6  9 12]               M2 [ 9 10 11 12]

同一M的输入凑齐：10/11/12         同一M的输入凑齐：4/8/12
```

这是任务编号，不是并行执行耗时；图中12个任务甚至可能一轮就被32核全部分走，不能据此推算提前多少μs。
真实I3072按128列配对时有24个N任务，三个M共72个任务；固定M完成可以把首个M的24个任务集中在首轮，实际效果仍取决于分核、完成事件和AIV1消费进度。

| 取舍 | 固定M、遍历N的影响 |
|---|---|
| 下游推进 | 一批行更早凑齐完整I，有机会提前SwiGLU收尾、GMM2及Combine |
| 数据复用 | 更集中复用同一批A；但相同B在多个M之间的复用距离可能拉长 |
| 并行与公平性 | 小任务/尾块可能分配不均，其他M更晚开始；不能只看第一批完成时间 |

但不能看到swizzle就判它不优：本例有效M128只有一个调度M-block，swizzle已经退化为沿N遍历，改顺序没有空间。
多M场景也要检查两道门：**ready是否按M-block发布；外层是否允许GMM2在当前Wave的GMM1全部提交前介入。** 后一道门没打开，前面提前就绪也可能没有收益。

更激进地让GMM2消费尚未凑齐的部分I，需要新的分K累加和量化/完成协议，已经不是简单改swizzle。

### 3. 后续实验的判定标准

先选多M专家，固定tile、缓存和数学合同，只改一个调度或布局因素；确认有效路径确实变化。观察首个M-block完整就绪、首个GMM2、最终kernel Duration三者是否同时改善。
既看收益，也看代价：MTE2读取组织、输出反压、缓存复用、尾块与credit回收。图更满、某个wait更短，都不能单独证明端到端更快。

## 代码与证据入口

代码基准为本地原Wave恢复版，不冒充最新远端master；按函数名阅读比依赖易变行号更方便。

| 主题 | 入口 |
|---|---|
| K512/N128策略、L1分区 | [a8w4_k_plan.hpp](C:/Project/Infra/ops-transformer-hs/.codex_worktrees/megamoe-r31-original-wave-1021/experiments/megamoe/csrc/kernels/mega_moe/catlass_gmm/a8w4_k_plan.hpp)：`MakeA8W4KPlan`、`A8W4BufferPlan` |
| AIV0读取、展开、UB→L1 | [block_prologue_a8w4.hpp](C:/Project/Infra/ops-transformer-hs/.codex_worktrees/megamoe-r31-original-wave-1021/experiments/megamoe/csrc/kernels/mega_moe/catlass_gmm/block_prologue_a8w4.hpp)：`ProcessL1Nz`、`RegComputeNz`、`CopyUb2L1` |
| L0装载、A复用、SF预取 | [block_mmad_a8w4.hpp](C:/Project/Infra/ops-transformer-hs/.codex_worktrees/megamoe-r31-original-wave-1021/experiments/megamoe/csrc/kernels/mega_moe/catlass_gmm/block_mmad_a8w4.hpp)：`operator()`、`MmadPairedB` |
| GMM1完成事件与CV槽 | [gmm1_async_completion.hpp](C:/Project/Infra/ops-transformer-hs/.codex_worktrees/megamoe-r31-original-wave-1021/experiments/megamoe/csrc/kernels/mega_moe/common/gmm1_async_completion.hpp)、[gmm1_cv_plan.hpp](C:/Project/Infra/ops-transformer-hs/.codex_worktrees/megamoe-r31-original-wave-1021/experiments/megamoe/csrc/kernels/mega_moe/common/gmm1_cv_plan.hpp)：`AcquireProducer`、`PublishCompleted`、`ReleaseConsumer`、`Gmm1CvStep` |
| CV原地压缩与stage写出 | [block_epilogue_activation_mx_quant.hpp](C:/Project/Infra/ops-transformer-hs/.codex_worktrees/megamoe-r31-original-wave-1021/experiments/megamoe/csrc/kernels/mega_moe/epilogue/block_epilogue_activation_mx_quant.hpp)：`RunCvStep`；[swiglu_mx_fused.hpp](C:/Project/Infra/ops-transformer-hs/.codex_worktrees/megamoe-r31-original-wave-1021/experiments/megamoe/csrc/kernels/mega_moe/epilogue/activation/swiglu_mx_fused.hpp)：`SwiGluMxFused` |
| 离线权重与SF重排 | [api.py](C:/Project/Infra/ops-transformer-hs/.codex_worktrees/megamoe-r31-original-wave-1021/experiments/megamoe/python/deep_ep_experimental/megamoe/api.py)：`_tilepack_fp4_for_nz_cast`、`_pack_weight_scale_blocks` |
| swizzle及GMM2输入门槛 | [mega_moe_block_scheduler.hpp](C:/Project/Infra/ops-transformer-hs/.codex_worktrees/megamoe-r31-original-wave-1021/experiments/megamoe/csrc/kernels/mega_moe/common/mega_moe_block_scheduler.hpp)、[mega_moe_gmm2_combine.hpp](C:/Project/Infra/ops-transformer-hs/.codex_worktrees/megamoe-r31-original-wave-1021/experiments/megamoe/csrc/kernels/mega_moe/stage/mega_moe_gmm2_combine.hpp)：`WaitForGmm2InputReady` |
| SF预取、SF排布及FP4预排的历史测量 | [results.json](C:/Project/Infra/ops-transformer-hs/outputs/megamoe-github-pages-1021/site/megamoe-performance/results.json)：`stage1.ds_bisect`、`stage1.ds_converge`；早期SF预取、SF重排、FP4预排、CATLASS预取的设备提交依次为`58beee1`、`ada45c8`、`ec59e53`、`ac948ee` |
| UB布局、padding与交错双槽 | 另见[UB bank冲突笔记](MegaMoE_UB_bank冲突笔记.md) |

历史性能主要取正式20轮的后10轮、逐轮rank-min均值，并保存rank-max；这不是全局最慢rank完成时间。输出逐位回归不等于独立Golden；不同硬件窗口、父版及数学合同的收益不可相加。

配图保存在本文同级的 `megamoe-layout-figures/`，PNG可直接在Markdown预览中显示，SVG和生成脚本便于后续修改。复制文档时，请同时带上该目录以及你原来的 `image.png`。
