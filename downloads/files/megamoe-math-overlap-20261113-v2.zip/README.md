先读正文 Markdown 或阅读版.html；assets 需与正文同目录。HTML公式使用MathJax CDN，离线时可阅读Markdown中的LaTeX。verify_math.py需要NumPy，仅运行CPU数学检查；不启动NPU或性能实验。
