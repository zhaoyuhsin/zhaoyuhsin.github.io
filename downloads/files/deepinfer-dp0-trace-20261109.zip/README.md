# DeepInfer DP0：71轮Host / Device对照原始Trace

在线学习台：https://zhaoyuhsin.github.io/deepinfer-trace/
采样日期：2026-10-27；本次公开：2026-11-09。

解压continuous-dp0.json，在MindStudio Insight中导入。文件约231.6 MB，解压和导入需要等待。
这是交互时间轴对应的DP0 driver原始trace，保持原始字节不变；不是全部16个rank的采样。
部署为16 NPU，DP2 / CP8 / EP16；自然路由，EPLB开启，DFlash草稿提议数5。
71轮是37轮占位、1轮prefill、33轮decode，不是71条用户请求。
该负载是两条短中文请求的教学采样，不代表生产吞吐或SLA。
主模型prefill设备边界为推定，decode为已记录图窗口；kernel覆盖率不是MFU。
本包只包含原始DP0 trace、说明与校验值，不附服务器日志、访问配置或环境脚本。
